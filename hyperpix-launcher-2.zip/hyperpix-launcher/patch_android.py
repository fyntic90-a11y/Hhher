import pathlib
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
t = m.read_text()
home = """
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.HOME" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
"""
t = t.replace("</activity>", home + "        </activity>", 1)
m.write_text(t)
print("patched")
